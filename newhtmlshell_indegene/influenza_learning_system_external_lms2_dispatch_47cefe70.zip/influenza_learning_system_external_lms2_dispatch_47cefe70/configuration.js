DispatchRoot='https://cloud.scorm.com/ScormEngineInterface/dispatch/';
ContentAPI='https://cloud.scorm.com/ScormEngineInterface/dispatch//DispatchHost.html';
ContentURL='https://cloud.scorm.com/EngineWebServices/api?method=rustici.dispatch.launch&dispatchid=47cefe70-3288-4181-90d8-365dcef4125a&launchsecret=qhkrrW4cJKe6xAUbkR6GSQkIyO4FeXmLM7j1GZTK&learnerid=LEARNER_ID&fname=LEARNER_FNAME&lname=LEARNER_LNAME&referringurl=REFERRING_URL&pipeurl=PIPE_URL&redirecturl=REDIRECT_URL&cssurl=CSS_URL_REGISTRATION_ARGUMENT';
DefaultCssUrl='https://cloud.scorm.com/sc/css/cloudPlayer/cloudstyles.css';
DispatchVersion=1;
TcapiEndpoint='https://cloud.scorm.com/ScormEngineInterface/TCAPI/Y5D06DPSEE';
