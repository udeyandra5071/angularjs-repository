function nisedit(){
     $(".contenteditable").on("click",function(){
       $(this).prop("contenteditable","true"); 
     $(".elementbar").show();
    });
}

$(document).ready(function(){
   nisedit();
})