php-xml-crud
============

XML CRUD Application written in PHP
