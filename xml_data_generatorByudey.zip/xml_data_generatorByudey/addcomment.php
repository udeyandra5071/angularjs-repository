<?php
// Udeyandra Kumar Xml CRUD
?>
<html>
<head>
    <title>My XML Parser</title>
	<link rel="stylesheet" type="text/css" href="css/cff.css" />
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
	</head>
<body>
<div class="popupCff">

    <ul>
        <li><a href="view.php?list">List All Users</a></li>
       <!-- <li>
            <form method="POST" action="process.php?filter">
                <input type="text" value='' name="name"/>
                <input type="submit" value="Filter"/>
				
            </form>
        </li>-->
        <li><a href="view.php?add">Add Comment</a></li>
    </ul>
	</div>
</body>
</html>







