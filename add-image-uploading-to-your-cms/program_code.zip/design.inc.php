<?php

$design_header= <<<__HTML_END

<!-- Add your site's header here -->

__HTML_END;

$design_footer= <<<__HTML_END

<!-- Add your site's footer here -->

__HTML_END;

?>