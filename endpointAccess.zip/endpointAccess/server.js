// ================ Base Setup ========================
// Include Hapi package
var hapi = require('hapi');

// Create Server Object
var server = new hapi.Server();

// Define PORT number
server.connection({port: 7002});
var request = require('request');
 
var options = {
  url: 'http://ae02-openapi.kohlsecommerce.com/v1/product/656485?skuDetail=true&invFilter=false',
  headers: {
    'User-Agent': 'request',
    'Accept':'application/json',
    'X-APP-API_KEY':'JBmYK1DyITEQAmUa27kWIpOjSZyyHAJR',
    'SECRET':'KnyK31GAMz585uAU'
  }
};
  var info;
function callback(error, response, body) {
  if (!error && response.statusCode == 200) {
    info = JSON.parse(body);
    //console.log(JSON.stringify(info) + " Stars");
     //JSON.stringify(info);
   // console.log(info.forks_count + " Forks");
  }
    else{
        info = "Internal Server Issue";
    }
}
 
request(options, callback);

// =============== Routes for our API =======================
// Define GET route
server.route({
    method: 'GET',      // Methods Type
    path: '/api/pmp',  // Url
   
    handler: function (request, reply) { //Action

        // Response JSON object
        reply({
            //statusCode: 200,
            //message: 'Getting All User Data',
            data:info
        });
    }
});

// =============== Start our Server =======================
// Lets start the server
server.start(function () {
    console.log('Server running at:', server.info.uri);
});